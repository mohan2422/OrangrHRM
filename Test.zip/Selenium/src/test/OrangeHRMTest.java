package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class OrangeHRMTest {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        //Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("Admin", "admin123");

        //Navigate to PIM
        DashboardPage dashboard = new DashboardPage(driver);
        dashboard.navigateToPIM();

        // Add 3 employees
        AddEmployeePage addEmployeePage = new AddEmployeePage(driver);
        String[][] employees = {
            {"John", "Doe"},
            {"Jane", "Smith"},
            {"Alan", "Walker"}
        };
        addEmployeePage.addMultipleEmployees(employees);

        dashboard.logout();

        driver.quit();
    }
}
