package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class PIMPage {
    private WebDriver driver;

    private By addEmployeeBtn = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--secondary']");
    private By employeeListBtn = By.xpath("//a[text()='Employee List']");

    public PIMPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickAddEmployee() {
       // driver.findElement(addEmployeeBtn).click();
        new Actions(driver).moveToElement(driver.findElement(addEmployeeBtn)).click().perform();
    }

    public void goToEmployeeList() {
        driver.findElement(employeeListBtn).click();
    }
}

