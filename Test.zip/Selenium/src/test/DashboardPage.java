package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class DashboardPage {
    private WebDriver driver;

    private By pimMenu = By.xpath("(//a[@class='oxd-main-menu-item'])[2]");
    private By userDropdown = By.cssSelector(".oxd-userdropdown-name");
    private By logoutLink = By.xpath("//a[text()='Logout']");

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
    }

    public void navigateToPIM() {
        new Actions(driver).moveToElement(driver.findElement(pimMenu)).click().perform();
    }

    public void logout() {
        driver.findElement(userDropdown).click();
        driver.findElement(logoutLink).click();
    }
}
