package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class EmployeeListPage {
    private WebDriver driver;

    private By employeeRows = By.xpath("//div[@class='oxd-table-body']//div[@role='row']");

    public EmployeeListPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean verifyEmployeeByName(String name) {
        List<WebElement> rows = driver.findElements(employeeRows);
        for (WebElement row : rows) {
            if (row.getText().contains(name)) {
                System.out.println("Name Verified: " + name);
                return true;
            }
        }
        return false;
    }
}

