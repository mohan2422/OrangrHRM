package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AddEmployeePage {
    private WebDriver driver;

   
    private By firstName = By.name("firstName");
    private By lastName = By.name("lastName");
    private By saveBtn = By.xpath("//button[@type='submit']");
    private By pimMenu = By.xpath("//span[text()='PIM']");
    private By addEmployeeLink = By.xpath("//a[text()='Add Employee']");

   
    public AddEmployeePage(WebDriver driver) {
        this.driver = driver;
    }

    
    public void addMultipleEmployees(String[][] employees) {
        for (String[] emp : employees) {
            driver.findElement(firstName).sendKeys(emp[0]);
            driver.findElement(lastName).sendKeys(emp[1]);
            driver.findElement(saveBtn).click();

            // Navigate back to Add Employee page
            driver.findElement(pimMenu).click();
            driver.findElement(addEmployeeLink).click();
        }
    }

}


